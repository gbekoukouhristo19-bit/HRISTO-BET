# HRISTO BET — prototype de démonstration

Prototype web responsive / PWA avec jeu Crash simulé et crédits virtuels uniquement.

## Important
- Aucun dépôt ni retrait d'argent réel.
- Aucun paiement Binance ou crypto n'est intégré.
- Le jeu Crash est une simulation locale, sans fournisseur externe.
- Le solde est stocké dans le navigateur (`localStorage`) et n'est pas un compte sécurisé.
- Ne pas utiliser ce prototype pour accepter des mises réelles.

## Tester en local
Ouvrir `index.html` dans un navigateur. Pour tester l'installation PWA et le service worker, servir le dossier via un serveur HTTP local.

## Publier sur GitHub
1. Ouvrir le dépôt `HRISTO-BET` sur GitHub.
2. Cliquer sur **Add file** puis **Upload files**.
3. Décompresser l'archive et téléverser les fichiers du dossier (pas le dossier parent).
4. Cliquer sur **Commit changes**.
5. Pour GitHub Pages : Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

## Prochaines étapes
Pour passer d'un prototype à une application réelle, il faudra concevoir un backend sécurisé, une authentification robuste, des journaux d'audit et une revue juridique des marchés ciblés. Toute fonction d'argent réel reste désactivée tant que les autorisations et accords requis ne sont pas confirmés.
