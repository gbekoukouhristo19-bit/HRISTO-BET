const $ = (id) => document.getElementById(id);
const DEFAULT_BALANCE = 10000;
let balance = Number(localStorage.getItem("hristo_demo_balance") || DEFAULT_BALANCE);
let rounds = Number(localStorage.getItem("hristo_demo_rounds") || 0);
let running = false, crashAt = 0, current = 1, bet = 0, timer = null, cashed = false;
const format = n => Math.floor(n).toLocaleString("fr-FR");
function render(){
  $("balance").textContent = format(balance);
  $("walletBalance").textContent = format(balance);
  $("rounds").textContent = rounds;
  localStorage.setItem("hristo_demo_balance", balance);
  localStorage.setItem("hristo_demo_rounds", rounds);
}
function setMessage(message){ $("gameMessage").textContent = message; }
function stopRound(message){
  running = false; clearInterval(timer);
  $("startRound").disabled = false; $("cashOut").disabled = true;
  $("startRound").textContent = "Nouvelle partie";
  setMessage(message); render();
}
$("playCrash").addEventListener("click", () => {
  $("playArea").hidden = false;
  $("playArea").scrollIntoView({behavior:"smooth"});
});
$("closeGame").addEventListener("click", () => $("playArea").hidden = true);
$("startRound").addEventListener("click", () => {
  if(running) return;
  bet = Math.floor(Number($("betAmount").value));
  if(!Number.isFinite(bet) || bet < 10 || bet > 1000){setMessage("Choisis une mise entre 10 et 1 000 crédits.");return;}
  if(bet > balance){setMessage("Solde de démonstration insuffisant.");return;}
  balance -= bet; rounds++; current = 1; cashed = false;
  // Randomized local demonstration only; not connected to a real game provider.
  crashAt = Math.max(1.01, Math.min(12, 1 + (-Math.log(Math.random()) * 1.65)));
  running = true; $("startRound").disabled = true; $("cashOut").disabled = false;
  $("crashNumber").textContent = "1.00x"; setMessage("La manche a commencé… encaisse avant le crash fictif.");
  render();
  timer = setInterval(() => {
    current += 0.025 + current * 0.008;
    $("crashNumber").textContent = current.toFixed(2) + "x";
    $("heroMultiplier").innerHTML = current.toFixed(2) + "<span>x</span>";
    if(current >= crashAt){
      $("crashNumber").textContent = crashAt.toFixed(2) + "x";
      stopRound(cashed ? "Manche terminée. Tes crédits démo encaissés sont conservés." : "Crash ! Cette mise virtuelle est perdue. Essaie une nouvelle manche.");
    }
  }, 100);
});
$("cashOut").addEventListener("click", () => {
  if(!running || cashed) return;
  const won = Math.floor(bet * current);
  balance += won; cashed = true;
  $("cashOut").disabled = true;
  setMessage("Crédits démo encaissés : +" + format(won) + " à " + current.toFixed(2) + "x. Attends la fin de la manche.");
  render();
});
$("resetBalance").addEventListener("click", () => {
  if(running){setMessage("Termine la manche avant de réinitialiser.");return;}
  balance = DEFAULT_BALANCE; rounds = 0; render();
  $("crashNumber").textContent = "1.00x"; setMessage("Solde de démonstration réinitialisé.");
});
$("year").textContent = new Date().getFullYear();
render();
let deferredPrompt;
window.addEventListener("beforeinstallprompt", (e) => {e.preventDefault();deferredPrompt=e;$("installBtn").hidden=false;});
$("installBtn").addEventListener("click", async () => {
  if(!deferredPrompt)return;
  deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt=null; $("installBtn").hidden=true;
});
if("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(()=>{}));
}
